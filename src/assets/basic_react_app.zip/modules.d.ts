declare module '*.zip';
