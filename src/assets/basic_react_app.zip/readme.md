# Project installation

    `npm install`

# Start the devserver

    `npm start`

# Build the production environment

    `npm run build`
